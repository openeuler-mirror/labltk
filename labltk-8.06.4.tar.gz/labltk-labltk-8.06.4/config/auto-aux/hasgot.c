main() {
  Tk_SetGrid();
}
